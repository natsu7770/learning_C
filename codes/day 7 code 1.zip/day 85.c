#include <stdio.h>

// Enumeration with explicit values starting from 10
enum Letters {
    A = 10,
    B = 11,
    C = 12
};

int main() {
    printf("A=%d\n", A);
    printf("B=%d\n", B);
    printf("C=%d\n", C);
    
    return 0;
}