#include <stdio.h>

int main() {
    // First group: 4 stars
    printf("*\n");
    printf("*\n");
    printf("*\n");
    printf("*\n");
    printf("\n");  // Blank line
    
    // Second group: 5 stars
    printf("*\n");
    printf("*\n");
    printf("*\n");
    printf("*\n");
    printf("*\n");
    printf("\n");  // Blank line
    
    // Third group: 3 stars
    printf("*\n");
    printf("*\n");
    printf("*\n");
    printf("\n");  // Blank line
    
    // Fourth group: 1 star
    printf("*\n");
    
    return 0;
}
