#include <stdio.h>

int main() {
    int rows = 5;

    // Print pattern
    for (int i = 1; i <= rows; i++) {
        printf("*****\n");
    }

    return 0;
}
